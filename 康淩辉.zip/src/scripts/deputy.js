define(["host"], function(){
	console.log("bbbbbb")
})