
define(["common","jquery"], function(com,fq){
	
})